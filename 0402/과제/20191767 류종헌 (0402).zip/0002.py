a = int(input("첫 번째 정수를 입력하시오: "))
b = int(input("두 번째 정수를 입력하시오: "))

if a > b:
    print(f"더 큰 정수는 {a}입니다")
else:
    print(f"더 큰 정수는 {b}입니다")