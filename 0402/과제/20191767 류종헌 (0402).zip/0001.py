sheep = int(input("정수를 입력하시오: "))

n = 3

if sheep % n == 0:
    print(str(n)+"의 배수입니다.")
else:
    print(str(n)+"의 배수가 아닙니다.")