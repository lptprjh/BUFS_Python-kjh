age = int(input("나이를 입력하시오: "))
tall = int(input("키를 입력하시오: "))

if age >= 12 and tall >= 120:
    print("탑승 가능합니다.")
else:
    print("탑승 불가입니다.")