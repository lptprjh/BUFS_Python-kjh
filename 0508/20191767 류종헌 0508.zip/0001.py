def Circle(r):
    return 2.0  *3.141592653589793*r

print(Circle(float(input)))