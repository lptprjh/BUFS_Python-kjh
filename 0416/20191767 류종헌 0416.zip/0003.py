result = 0
i = 0

while i<=100:
    if i%2 == 0:
        result += i
    i = i+1

print(result)